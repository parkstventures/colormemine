import boto3
import os
import datetime

from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    
    custname = event["cust"]
    now = datetime.datetime.now()
    
    if not custname:
        custname = "*"
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ['DB_TABLE_NAME'])
    
    if custname=="*":
        items = table.query(
            IndexName='createdate-index',
            KeyConditionExpression=Key('createdate').eq(now.strftime("%Y-%m-%d"))
        )
    else:
        items = table.query(
            KeyConditionExpression=Key('lastname').eq(custname.upper())
        )
     
       
        
    return items["Items"]
