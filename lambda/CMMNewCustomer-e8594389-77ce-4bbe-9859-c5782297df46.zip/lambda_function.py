# -*- coding: utf-8 -*-
import boto3
import os
import uuid
import datetime


def lambda_handler(event, context):
    
    #recordId = str(uuid.uuid4())
    fname = event["firstname"]
    lname = event["lastname"]
    phone = event["phonenumber"]
    email = event["email"]
    zipcode = event["zipcode"]
    
    now = datetime.datetime.now()
    
    #print('Generating new DynamoDB record, with ID: ' + recordId)


    #Creating new record in DynamoDB table
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(os.environ['DB_TABLE_NAME'])
    table.put_item(
               Item={
               'firstname' : fname.upper(),
               'lastname' : lname.upper(),
               'phonenum' : phone,
               'email' : email,
               'zipcode' : zipcode,
                'createdate': now.strftime("%Y-%m-%d")
               }
    )
  
    # register customer 
    
    #add a 1 to the phone number. we also need to add some kind of validation!
    #if len(phone) == 10:
    phone = "1" + phone

    client = boto3.client('sns')

    response2 = client.publish(
        PhoneNumber=phone,
        Message= 'Welcome to CMM Manassas. Happy Summer. Text STOP to opt out'
    )
    
    response1 = client.subscribe(
        TopicArn=os.environ['SNS_TOPIC'],
        Protocol='sms',
        Endpoint=phone
    )
    
    return "thank you"



